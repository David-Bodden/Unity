﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    public float flSpeed;
    public float flJumpPower;
	public Sprite sprPlayer;
	public Sprite sprPlayerWNormal;

    private Rigidbody2D rb2RigidBody;
    private SpriteRenderer srSpriteRenderer;
    private EdgeCollider2D ec2BlockCheck;
    private bool bIsJumping = false;
    private Collider2D c2Block = null;
	private bool bHoldingBlock = false;
	private GameObject gobjHeldBlock;

    private void Start()
    {
        rb2RigidBody = GetComponent<Rigidbody2D>();
        srSpriteRenderer = GetComponent<SpriteRenderer>();
        ec2BlockCheck = transform.Find("BlockCheck").gameObject.GetComponent<EdgeCollider2D>();
    }

    private void FixedUpdate()
    {
        float flMoveHorizontal = Input.GetAxis("Horizontal");
        Vector2 v2MoveHorizontal = new Vector2(flMoveHorizontal, 0.0f);

        if (0 > flMoveHorizontal)
        {
            srSpriteRenderer.flipX = true;
            ec2BlockCheck.offset = new Vector2(-0.26f, 0.0f);
        }
        else if (0 < flMoveHorizontal)
        {
            srSpriteRenderer.flipX = false;
            ec2BlockCheck.offset = new Vector2(0.26f, 0.0f);
        }

        rb2RigidBody.AddForce(v2MoveHorizontal * flSpeed);

        if (!bIsJumping && Input.GetKeyDown("up"))
        {
            Vector2 v2MoveVertical = new Vector2(0.0f, 1.0f);

            rb2RigidBody.AddForce(v2MoveVertical * flJumpPower, ForceMode2D.Impulse);
            bIsJumping = true;
        }

		if (!bIsJumping && Input.GetKeyDown ("down"))
		{
			if (!bHoldingBlock && c2Block != null && !c2Block.CompareTag("Wall"))
			{
				gobjHeldBlock = c2Block.gameObject;
				gobjHeldBlock.SetActive(false);
				bHoldingBlock = true;
				srSpriteRenderer.sprite = sprPlayerWNormal;
			}
			else if (bHoldingBlock && c2Block == null)
			{
				if (srSpriteRenderer.flipX == true)
				{
					gobjHeldBlock.transform.position = new Vector3(transform.position.x - 0.5f, transform.position.y, 0.0f);
				}
				else
				{
					gobjHeldBlock.transform.position = new Vector3(transform.position.x + 0.5f, transform.position.y, 0.0f);
				}
				gobjHeldBlock.SetActive(true);
				bHoldingBlock = false;
				srSpriteRenderer.sprite = sprPlayer;
			}	
		}
    }

    private void GroundCollision()
    {
        bIsJumping = false;
    }

	private void BlockFound(Collider2D other)
    {
		c2Block = other;
    }

    private void BlockLost()
    {
		c2Block = null;
    }
}
