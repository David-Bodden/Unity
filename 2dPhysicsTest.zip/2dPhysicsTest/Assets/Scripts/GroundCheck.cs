﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GroundCheck : MonoBehaviour {

    public GameObject gobjPlayer;

	private void OnTriggerEnter2D(Collider2D other)
    {
        gobjPlayer.SendMessage("GroundCollision");
    }
}
