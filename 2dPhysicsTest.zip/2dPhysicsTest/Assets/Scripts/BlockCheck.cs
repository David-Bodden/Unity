﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockCheck : MonoBehaviour {

    public GameObject gobjPlayer;

    private void OnTriggerEnter2D(Collider2D other)
    {
		gobjPlayer.SendMessage("BlockFound", other);
    }
    
    private void OnTriggerExit2D(Collider2D other)
    {
        gobjPlayer.SendMessage("BlockLost");
    }
}
