﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour {

	public Camera camMainCamera;
	public GameObject gobjCursor = null;

	private float flMaxHorizontal;
	private float flMaxVertical;

	private bool bUnitSelected = false;
	private bool bUnitAttacking = false;
	private bool bTeam1Turn = true;
	private GameObject gobjUnitSelected = null;

	private SpriteRenderer[] asrUnits;
	private SpriteRenderer[] asrTerrain;
	private List<GameObject> lgobjTeam1Units = new List<GameObject>();
	private List<GameObject> lgobjTeam2Units = new List<GameObject>();
	private List<GameObject> lgobjTerrain = new List<GameObject>();

	private Color rgbTerrainHighlight = new Color(1.0f, 0.5f, 0.0f, 1.0f);
	private Color rgbAttackHighlight = new Color(0.0f, 0.5f, 1.0f, 1.0f);
	private Color rgbUnitDone = new Color(0.5f, 0.5f, 0.5f, 1.0f);
	private Color rgbClear = new Color(1.0f, 1.0f, 1.0f, 1.0f);

	void Start()
	{
		if (camMainCamera == null)
		{
			camMainCamera = Camera.main;
		}
			
		asrUnits = GameObject.Find("Team1Units").GetComponentsInChildren<SpriteRenderer>();

		foreach (SpriteRenderer srUnit in asrUnits)
		{
			if (srUnit.gameObject == null)
			{
				print("unit gameobject is null");
			}
			else
			{
				lgobjTeam1Units.Add(srUnit.gameObject);
			}
		}

		asrUnits = GameObject.Find("Team2Units").GetComponentsInChildren<SpriteRenderer>();

		foreach (SpriteRenderer srUnit in asrUnits)
		{
			if (srUnit.gameObject == null)
			{
				print("unit gameobject is null");
			}
			else
			{
				srUnit.color = rgbUnitDone;
				lgobjTeam2Units.Add(srUnit.gameObject);
			}
		}

		asrTerrain = GameObject.Find("Terrain").GetComponentsInChildren<SpriteRenderer>();

		foreach (SpriteRenderer srTerrain in asrTerrain)
		{
			if (srTerrain.gameObject == null)
			{
				print("terrain gameobject is null");
			}
			else
			{
				lgobjTerrain.Add(srTerrain.gameObject);
			}
		}

		Vector3 V3UpperCorner = new Vector3(Screen.width, Screen.height, 0.0f);
		Vector3 V3Target = camMainCamera.ScreenToWorldPoint(V3UpperCorner);
		float flSpriteWidth = gobjCursor.GetComponent<Renderer>().bounds.extents.x;
		float flSpriteHeight = gobjCursor.GetComponent<Renderer>().bounds.extents.y;
		flMaxHorizontal = V3Target.x - flSpriteWidth;
		flMaxVertical = V3Target.y - flSpriteHeight;
	}
		
	void Update()
	{
		Vector3 V3NewPosition;

		if (Input.GetKeyDown("up"))
		{
			V3NewPosition = new Vector3(gobjCursor.transform.position.x, gobjCursor.transform.position.y + 0.5f);

			float flNewY = Mathf.Clamp(V3NewPosition.y, -flMaxVertical, flMaxVertical);

			V3NewPosition = new Vector3(V3NewPosition.x, flNewY);

			if (bUnitAttacking)
			{
				if (CheckAttack(V3NewPosition))
				{
					gobjCursor.transform.position = V3NewPosition;
				}
			}
			else if (bUnitSelected)
			{
				if (CheckMove(V3NewPosition))
				{
					gobjUnitSelected.transform.position = V3NewPosition;
					gobjCursor.transform.position = V3NewPosition;
				}
			}
			else
			{
				gobjCursor.transform.position = V3NewPosition;
			}
		}
		if (Input.GetKeyDown("right"))
		{
			V3NewPosition = new Vector3(gobjCursor.transform.position.x + 0.5f, gobjCursor.transform.position.y);

			float flNewX = Mathf.Clamp(V3NewPosition.x, -flMaxHorizontal, flMaxHorizontal);

			V3NewPosition = new Vector3(flNewX, V3NewPosition.y);

			if (bUnitAttacking)
			{
				if (CheckAttack(V3NewPosition))
				{
					gobjCursor.transform.position = V3NewPosition;
				}
			}
			else if (bUnitSelected)
			{
				if (CheckMove(V3NewPosition))
				{
					gobjUnitSelected.transform.position = V3NewPosition;
					gobjCursor.transform.position = V3NewPosition;
				}
			}
			else
			{
				gobjCursor.transform.position = V3NewPosition;
			}
		}
		if (Input.GetKeyDown("down"))
		{
			V3NewPosition = new Vector3(gobjCursor.transform.position.x, gobjCursor.transform.position.y - 0.5f);

			float flNewY = Mathf.Clamp(V3NewPosition.y, -flMaxVertical, flMaxVertical);

			V3NewPosition = new Vector3(V3NewPosition.x, flNewY);

			if (bUnitAttacking)
			{
				if (CheckAttack(V3NewPosition))
				{
					gobjCursor.transform.position = V3NewPosition;
				}
			}
			else if (bUnitSelected)
			{
				if (CheckMove(V3NewPosition))
				{
					gobjUnitSelected.transform.position = V3NewPosition;
					gobjCursor.transform.position = V3NewPosition;
				}
			}
			else
			{
				gobjCursor.transform.position = V3NewPosition;
			}
		}
		if (Input.GetKeyDown("left"))
		{
			V3NewPosition = new Vector3(gobjCursor.transform.position.x - 0.5f, gobjCursor.transform.position.y);

			float flNewX = Mathf.Clamp(V3NewPosition.x, -flMaxHorizontal, flMaxHorizontal);

			V3NewPosition = new Vector3(flNewX, V3NewPosition.y);

			if (bUnitAttacking)
			{
				if (CheckAttack(V3NewPosition))
				{
					gobjCursor.transform.position = V3NewPosition;
				}
			}
			else if (bUnitSelected)
			{
				if (CheckMove(V3NewPosition))
				{
					gobjUnitSelected.transform.position = V3NewPosition;
					gobjCursor.transform.position = V3NewPosition;
				}
			}
			else
			{
				gobjCursor.transform.position = V3NewPosition;
			}
		}

		if (Input.GetKeyDown("enter"))
		{
			if (bUnitAttacking)
			{
				ClearAttackZone();
				gobjUnitSelected.GetComponent<SpriteRenderer>().color = rgbUnitDone;
				bUnitAttacking = false;
				gobjUnitSelected = null;
				bUnitSelected = false;
				if (CheckTurnOver())
				{
					bTeam1Turn = !bTeam1Turn;
					ClearUnitDone();
				}
			}
			else if (bUnitSelected)
			{
				bUnitAttacking = true;
				ClearMoveZone();
				ShowAttackZone(gobjUnitSelected.transform.position, gobjUnitSelected.GetComponent<StatSheet>().nAtkRange);
			}
			else
			{
				gobjUnitSelected = GetSelectedUnit();
				if (gobjUnitSelected != null)
				{
					bUnitSelected = true;
					ShowMoveZone(gobjUnitSelected.transform.position, gobjUnitSelected.GetComponent<StatSheet>().nMoveRange);
				}
			}
		}
	}

	private GameObject GetSelectedUnit ()
	{
		if (bTeam1Turn)
		{
			foreach (GameObject gobjUnit in lgobjTeam1Units)
			{
				if ((gobjCursor.transform.position.Equals(gobjUnit.transform.position))
					&& (!gobjUnit.GetComponent<SpriteRenderer>().color.Equals(rgbUnitDone)))
				{
					return gobjUnit;
				}
			}
		}
		else
		{
			foreach (GameObject gobjUnit in lgobjTeam2Units)
			{
				if ((gobjCursor.transform.position.Equals(gobjUnit.transform.position))
					&& (!gobjUnit.GetComponent<SpriteRenderer>().color.Equals(rgbUnitDone)))
				{
					return gobjUnit;
				}
			}
		}

		print("found no objects with equal position");
		return null;
	}

	private bool CheckMove (Vector3 V3NewPosition)
	{
		foreach (GameObject gobjTerrain in lgobjTerrain)
		{
			if ((V3NewPosition.Equals(gobjTerrain.transform.position))
			    && (gobjTerrain.GetComponent<SpriteRenderer>().color.Equals(rgbTerrainHighlight)))
			{
				return true;
			}
		}
		return false;
	}

	private bool CheckAttack (Vector3 V3NewPosition)
	{
		foreach (GameObject gobjTerrain in lgobjTerrain)
		{
			if ((V3NewPosition.Equals(gobjTerrain.transform.position))
			    && (gobjTerrain.GetComponent<SpriteRenderer>().color.Equals(rgbAttackHighlight)))
			{
				return true;
			}
		}
		return false;
	}

	private bool CheckImpassable (Vector3 V3NewPosition)
	{
		foreach (GameObject gobjUnit in lgobjTeam1Units)
		{
			if (V3NewPosition.Equals(gobjUnit.transform.position))
			{
				return false;
			}
		}

		foreach (GameObject gobjUnit in lgobjTeam2Units)
		{
			if (V3NewPosition.Equals(gobjUnit.transform.position))
			{
				return false;
			}
		}
		return true;
	}

	private void ShowMoveZone (Vector3 V3CurrentPosition, int nMoves)
	{
		bool bFound = false;

		foreach (GameObject gobjTerrain in lgobjTerrain)
		{
			if (V3CurrentPosition.Equals(gobjTerrain.transform.position))
			{
				if (!gobjTerrain.GetComponent<SpriteRenderer>().color.Equals(rgbTerrainHighlight))
				{
					gobjTerrain.GetComponent<SpriteRenderer>().color = rgbTerrainHighlight;
				}
				bFound = true;
				break;
			}
		}
			
		if (bFound && (nMoves != 0))
		{
			nMoves--;
			Vector3 V3NewPosition = new Vector3(V3CurrentPosition.x, V3CurrentPosition.y + 0.5f);
			if (CheckImpassable(V3NewPosition))
			{
				ShowMoveZone(V3NewPosition, nMoves);
			}
			V3NewPosition = new Vector3(V3CurrentPosition.x, V3CurrentPosition.y - 0.5f);
			if (CheckImpassable(V3NewPosition))
			{
				ShowMoveZone(V3NewPosition, nMoves);
			}
			V3NewPosition = new Vector3(V3CurrentPosition.x + 0.5f, V3CurrentPosition.y);
			if (CheckImpassable(V3NewPosition))
			{
				ShowMoveZone(V3NewPosition, nMoves);
			}
			V3NewPosition = new Vector3(V3CurrentPosition.x - 0.5f, V3CurrentPosition.y);
			if (CheckImpassable(V3NewPosition))
			{
				ShowMoveZone(V3NewPosition, nMoves);
			}
		}
	}

	private void ShowAttackZone (Vector3 V3CurrentPosition, int nAttackRange)
	{
		bool bFound = false;

		foreach (GameObject gobjTerrain in lgobjTerrain)
		{
			if (V3CurrentPosition.Equals(gobjTerrain.transform.position)) 
			{
				if (!gobjTerrain.GetComponent<SpriteRenderer>().color.Equals(rgbAttackHighlight))
				{
					gobjTerrain.GetComponent<SpriteRenderer>().color = rgbAttackHighlight;
				}
				bFound = true;
				break;
			}
		}

		if (bFound && (nAttackRange != 0))
		{
			nAttackRange--;
			Vector3 V3NewPosition = new Vector3(V3CurrentPosition.x, V3CurrentPosition.y + 0.5f);
			ShowAttackZone(V3NewPosition, nAttackRange);

			V3NewPosition = new Vector3(V3CurrentPosition.x, V3CurrentPosition.y - 0.5f);
			ShowAttackZone(V3NewPosition, nAttackRange);
			
			V3NewPosition = new Vector3(V3CurrentPosition.x + 0.5f, V3CurrentPosition.y);
			ShowAttackZone(V3NewPosition, nAttackRange);

			V3NewPosition = new Vector3(V3CurrentPosition.x - 0.5f, V3CurrentPosition.y);
			ShowAttackZone(V3NewPosition, nAttackRange);
		}
	}

	private void ClearMoveZone ()
	{
		foreach (GameObject gobjTerrain in lgobjTerrain)
		{
			if (gobjTerrain.GetComponent<SpriteRenderer>().color.Equals(rgbTerrainHighlight))
			{
				gobjTerrain.GetComponent<SpriteRenderer>().color = rgbClear;
			}
		}
	}

	private void ClearAttackZone ()
	{
		foreach (GameObject gobjTerrain in lgobjTerrain)
		{
			if (gobjTerrain.GetComponent<SpriteRenderer>().color.Equals(rgbAttackHighlight))
			{
				gobjTerrain.GetComponent<SpriteRenderer>().color = rgbClear;
			}
		}
	}

	private bool CheckTurnOver ()
	{
		if (bTeam1Turn)
		{
			foreach (GameObject gobjUnit in lgobjTeam1Units)
			{
				if (!gobjUnit.GetComponent<SpriteRenderer>().color.Equals(rgbUnitDone))
				{
					return false;
				}
			}
		}
		else
		{
			foreach (GameObject gobjUnit in lgobjTeam2Units)
			{
				if (!gobjUnit.GetComponent<SpriteRenderer>().color.Equals(rgbUnitDone))
				{
					return false;
				}
			}
		}
			
		return true;
	}

	private void ClearUnitDone ()
	{
		if (bTeam1Turn)
		{
			foreach (GameObject gobjUnit in lgobjTeam1Units)
			{
				gobjUnit.GetComponent<SpriteRenderer>().color = rgbClear;
			}
		}
		else
		{
			foreach (GameObject gobjUnit in lgobjTeam2Units)
			{
				gobjUnit.GetComponent<SpriteRenderer>().color = rgbClear;
			}
		}
	}
}
