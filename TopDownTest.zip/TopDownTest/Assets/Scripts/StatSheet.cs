﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StatSheet : MonoBehaviour {
	public int nHitPoints;
	public int nDefenseValue;
	public int nMoveRange;
	public int nAtkRange;
	public int nAttackValue;
	public int nSpeedValue;
}