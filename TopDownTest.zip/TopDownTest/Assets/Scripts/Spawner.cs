﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour {

	public Transform Cursor;

	public Transform TerrainParent;
	public Transform[] Terrain;

	public Transform Team1Parent;
	public Transform Team2Parent;
	public Transform SniperRed;
	public Transform SniperBlue;
	public Transform BrawlerRed;
	public Transform BrawlerBlue;
	public Transform SmasherRed;
	public Transform SmasherBlue;
	public Transform SpearmanRed;
	public Transform SpearmanBlue;

	void Awake () {
		SpawnTerrain();
		SpawnTeam1();
		SpawnTeam2();
		SpawnCursor();
	}

	private void SpawnTerrain ()
	{
		int[] anTerrainIds = {
			4, 2, 1, 0, 2, 2, 1, 1, 0, 2, 0, 1, 0, 1, 1, 2,
			0, 5, 6, 5, 6, 0, 1, 2, 3, 0, 0, 0, 5, 6, 4, 3,
			2, 3, 1, 0, 0, 1, 2, 3, 3, 1, 0, 0, 4, 5, 6, 0,
			10, 10, 10, 9, 10, 10, 7, 8, 10, 10, 8, 10, 7, 10, 10, 9,
			15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15,
			9, 10, 9, 8, 7, 7, 8, 10, 7, 7, 9, 10, 10, 10, 10, 10,
			15, 17, 15, 15, 15, 15, 15, 15, 17, 15, 15, 15, 15, 15, 15, 15,
			0, 20, 0, 4, 5, 6, 0, 1, 20, 0, 1, 0, 3, 3, 3, 3,
			4, 20, 0, 12, 15, 11, 3, 4, 14, 15, 15, 11, 0, 1, 0, 1,
			2, 20, 0, 20, 1, 20, 1, 2, 3, 0, 0, 20, 1, 4, 5, 6,
			4, 20, 0, 19, 15, 18, 5, 6, 12, 15, 15, 13, 1, 0, 1, 0,
			1, 14, 15, 13, 0, 14, 15, 15, 13, 1, 0, 1, 0, 1, 0, 1
		};
			
		int nId = 0;

		for (float y = -2.75f; y <= 2.75f; y += 0.5f)
		{
			for (float x = -3.75f; x <= 3.75f; x += 0.5f)
			{
				Instantiate(Terrain[anTerrainIds[nId]], new Vector2(x, y), Quaternion.identity, TerrainParent);
				nId++;
			}
		}
	}

	private void SpawnTeam1 ()
	{
		//Static stat values. Real game would use a saved text file to load stats for certain units
		GameObject gobjUnit;
		gobjUnit = Instantiate(BrawlerRed, new Vector2(-1.75f, -1.75f), Quaternion.identity, Team1Parent).gameObject;
		gobjUnit.GetComponent<StatSheet>().nHitPoints = 15;
		gobjUnit.GetComponent<StatSheet>().nAtkRange = 1;
		gobjUnit.GetComponent<StatSheet>().nMoveRange = 3;
		gobjUnit.GetComponent<StatSheet>().nAttackValue = 6;
		gobjUnit.GetComponent<StatSheet>().nDefenseValue = 3;
		gobjUnit.GetComponent<StatSheet>().nSpeedValue = 7;
		gobjUnit = Instantiate(SmasherRed, new Vector2(-2.25f, -2.25f), Quaternion.identity, Team1Parent).gameObject;
		gobjUnit.GetComponent<StatSheet>().nHitPoints = 20;
		gobjUnit.GetComponent<StatSheet>().nAtkRange = 1;
		gobjUnit.GetComponent<StatSheet>().nMoveRange = 4;
		gobjUnit.GetComponent<StatSheet>().nAttackValue = 10;
		gobjUnit.GetComponent<StatSheet>().nDefenseValue = 2;
		gobjUnit.GetComponent<StatSheet>().nSpeedValue = 5;
		gobjUnit = Instantiate(SpearmanRed, new Vector2(-1.75f, -2.75f), Quaternion.identity, Team1Parent).gameObject;
		gobjUnit.GetComponent<StatSheet>().nHitPoints = 10;
		gobjUnit.GetComponent<StatSheet>().nAtkRange = 2;
		gobjUnit.GetComponent<StatSheet>().nMoveRange = 2;
		gobjUnit.GetComponent<StatSheet>().nAttackValue = 7;
		gobjUnit.GetComponent<StatSheet>().nDefenseValue = 4;
		gobjUnit.GetComponent<StatSheet>().nSpeedValue = 4;
		gobjUnit = Instantiate(SniperRed, new Vector2(-2.75f, -2.25f), Quaternion.identity, Team1Parent).gameObject;
		gobjUnit.GetComponent<StatSheet>().nHitPoints = 7;
		gobjUnit.GetComponent<StatSheet>().nAtkRange = 3;
		gobjUnit.GetComponent<StatSheet>().nMoveRange = 5;
		gobjUnit.GetComponent<StatSheet>().nAttackValue = 5;
		gobjUnit.GetComponent<StatSheet>().nDefenseValue = 1;
		gobjUnit.GetComponent<StatSheet>().nSpeedValue = 8;
	}

	private void SpawnTeam2 ()
	{
		//Static stat values. Real game would use a saved text file to load stats for certain units
		GameObject gobjUnit;
		gobjUnit = Instantiate(BrawlerBlue, new Vector2(1.75f, 1.75f), Quaternion.identity, Team2Parent).gameObject;
		gobjUnit.GetComponent<StatSheet>().nHitPoints = 15;
		gobjUnit.GetComponent<StatSheet>().nAtkRange = 1;
		gobjUnit.GetComponent<StatSheet>().nMoveRange = 3;
		gobjUnit.GetComponent<StatSheet>().nAttackValue = 6;
		gobjUnit.GetComponent<StatSheet>().nDefenseValue = 3;
		gobjUnit.GetComponent<StatSheet>().nSpeedValue = 7;
		gobjUnit = Instantiate(SmasherBlue, new Vector2(2.25f, 2.25f), Quaternion.identity, Team2Parent).gameObject;
		gobjUnit.GetComponent<StatSheet>().nHitPoints = 20;
		gobjUnit.GetComponent<StatSheet>().nAtkRange = 1;
		gobjUnit.GetComponent<StatSheet>().nMoveRange = 4;
		gobjUnit.GetComponent<StatSheet>().nAttackValue = 10;
		gobjUnit.GetComponent<StatSheet>().nDefenseValue = 2;
		gobjUnit.GetComponent<StatSheet>().nSpeedValue = 5;
		gobjUnit = Instantiate(SpearmanBlue, new Vector2(1.75f, 2.75f), Quaternion.identity, Team2Parent).gameObject;
		gobjUnit.GetComponent<StatSheet>().nHitPoints = 10;
		gobjUnit.GetComponent<StatSheet>().nAtkRange = 2;
		gobjUnit.GetComponent<StatSheet>().nMoveRange = 2;
		gobjUnit.GetComponent<StatSheet>().nAttackValue = 7;
		gobjUnit.GetComponent<StatSheet>().nDefenseValue = 4;
		gobjUnit.GetComponent<StatSheet>().nSpeedValue = 4;
		gobjUnit = Instantiate(SniperBlue, new Vector2(2.75f, 2.25f), Quaternion.identity, Team2Parent).gameObject;
		gobjUnit.GetComponent<StatSheet>().nHitPoints = 7;
		gobjUnit.GetComponent<StatSheet>().nAtkRange = 3;
		gobjUnit.GetComponent<StatSheet>().nMoveRange = 5;
		gobjUnit.GetComponent<StatSheet>().nAttackValue = 5;
		gobjUnit.GetComponent<StatSheet>().nDefenseValue = 1;
		gobjUnit.GetComponent<StatSheet>().nSpeedValue = 8;
	}

	private void SpawnCursor ()
	{
		GameObject gobjCursor;
		gobjCursor = Instantiate(Cursor, new Vector2(0.25f, 0.25f), Quaternion.identity).gameObject;
		GameObject.Find("GameController").GetComponent<GameController>().gobjCursor = gobjCursor;
	}
}
